#pragma once
#include <directxmath.h>
//#include <xnamath.h>

using namespace DirectX;

typedef long HRESULT;

struct ID3D11VertexShader;
struct ID3D11PixelShader;
struct ID3D11InputLayout;
struct ID3D11Buffer;
struct ID3D11Device;
struct ID3D11DeviceContext;
struct ID3D11ShaderResourceView;
struct ID3D11SamplerState;
struct ID3D11Buffer;
///struct XMMATRIX;

class Tree
{
private:
	ID3D11VertexShader*                 _pVertexShader;
	ID3D11PixelShader*                  _pPixelShader;
	ID3D11InputLayout*                  _pVertexLayout;
	ID3D11Buffer*                       _pVertexBuffer;
	ID3D11Buffer*                       _pIndexBuffer;
	ID3D11ShaderResourceView*           _pTextureRV;
	ID3D11SamplerState*                 _pSamplerLinear;
	ID3D11Buffer*                       _pCBChangesEveryFrame;

	struct Branch
	{
		XMFLOAT3 start;
		XMFLOAT3 end;
		float	thickness;
	};

public:
	Tree(void);
	~Tree(void);

	HRESULT Init(ID3D11Device* device, ID3D11DeviceContext* pImmediateContext);
	HRESULT CleanUpDeviceObjects();
	HRESULT Render(ID3D11DeviceContext* pImmediateContext, DirectX::XMMATRIX* world, float time);

private:
	HRESULT RenderBranch(ID3D11DeviceContext* pImmediateContext, DirectX::XMMATRIX const* world, Branch const* branch, float time);
};

